

<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



//include ('../../conexao/conexao_fb.php');
//$con = new conecta_bd();

function formataData($data){
    $i = explode('/', $data);
    $out = $i[1].'/'.$i[0].'/'.$i[2];
    return $out;
}

if (isset($_POST['acao'])) {
    $acao = $_POST['acao'];
    //echo $acao;
} else
    exit;


$conn = array(
    'user' => 'root',
    'pass' => '',
    'host' => 'localhost',
    'db' => 'tpe'
);
if (is_array($conn)) {
    try {
        $db = @new PDO(
                "mysql:host={$conn['host']};dbname={$conn['db']}", $conn['user'], $conn['pass'], array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
        );
    } catch (PDOException $e) {
        echo json_encode(array(
            "error" => "An error occurred while connecting to the database. " .
            "The error reported by the server was: " . $e->getMessage()
        ));
        exit(0);
    }
}



$escalado = 'N';

//$empresa = $_POST['empresa'];
//$reimpressao = 1;
//$data_i = formataData($_POST['dataInicio']);
//$data_f = formataData($_POST['dataFim']);
//$proprietario = $_POST['proprietario'];

//$empresa = 1;
//$reimpressao = 0;
//$data_i = '07/01/2016';
//$data_f = '07/30/2016';
//$proprietario = 4;

$sql =  "SELECT v.NOME,
                v.EMAIL,
                v.TELEFONE_1,
                v.TELEFONE_2,
                v.CONGREGACAO
         FROM voluntarios v
         WHERE ((v.ESCALADO=:ESCALADO))
         ORDER BY v.NOME";


$sth =$db->prepare($sql);
$sth->bindParam(':ESCALADO', $escalado, PDO::PARAM_STR);


//$sth->bindParam(':REIMPRESSAO', $reimpressao, PDO::PARAM_INT);
//$sth->bindParam(':DATA_I', $data_i, PDO::PARAM_STR, 10);
//$sth->bindParam(':DATA_F', $data_f, PDO::PARAM_STR, 10);    
//$sth->bindParam(':COD_PROP', $proprietario, PDO::PARAM_INT);


try{
    $sth->execute();    
}
catch (PDOException $e) {
    echo json_encode( array( 
            "error" => "erro na execução do sql: ".$e->getMessage()
    ) );
    exit(0); 
}

//echo 'breno - <br>';
//$row=$sth->fetch(PDO::FETCH_OBJ);  
//   echo $row->CODIGO; 
//while ($row=$sth->fetch(PDO::FETCH_OBJ)) { 
//   echo $row->IMOVEL .'-' ; 
//} 
//$row = $sth->fetch(PDO::FETCH_OBJ);
//echo    $row->EMPRESA.'';
//echo    $row->IMOVEL.'';
//echo    $row->SEQUENCIA.'';
//echo    $row->PARCELA.'';
//exit;
include('mpdf/mpdf.php');
$mpdf=new mPDF();
$mpdf->SetDisplayMode('fullpage');
//$css = file_get_contents("../../../assets/css/theme-default/relatorios.css");
$mpdf->WriteHTML($css,1);





$pagina=0;

$html_tracado='';
$html_tracado=$html_tracado.
        '<table border="0" width="100%" align="right" class="pontilhado">
            <tbody>
                <tr>
                    <td width="100%">_____________________________________________________________________________________________________________________________________________________________'.'</td>
            </tbody>                
        </table>'; 


$html_qtd_voluntarios='';


while ($row = $sth->fetch(PDO::FETCH_OBJ)){


//    
//    $html_qtd_voluntarios=$html_qtd_voluntarios.
//        '<table border="1" width="100%" align="center">
//            <tbody>
//                <tr>
//                    <td WIDTH="30%"> '.utf8_encode($row->nome).' </td>
//                    <td WIDTH="20%"> '.$row->email.' </td>
//                    <td WIDTH="20%" align="left"> '.$row->telefone_1.' </td>
//                    <td WIDTH="20%" align="left"> '.$row->telefone_2.' </td>
//                    <td WIDTH="10%" align="left"> '.$row->congregacao.' </td>
//                </tr>
//            </tbody>
//        </table>';

    
        $html_qtd_voluntarios=$html_qtd_voluntarios.
        '<table border="0" width="100%" align="center">
            <tbody>
                <tr>
                    <td WIDTH="30%"> '.utf8_encode($row->NOME).' </td>
                    <td WIDTH="30%"> '.$row->EMAIL.' </td>
                    <td WIDTH="20%"> '.$row->TELEFONE_1.' </td>
                    <td WIDTH="20%"> '.$row->TELEFONE_2.' </td>
                </tr>
            </tbody>
        </table>';
}


    
    
    
//    if ($pagina<>$row->X){
//        $pagina=$row->X;
//        $sqlSocios ="   SELECT PRP.COD_CLI,
//                                PRP.NOME_CLI,
//                                PRP.DESCR_F_PAGTO,
//                                PRP.NOME_BANCO,
//                                PRP.BANCO,
//                                PRP.AGENCIA,
//                                PRP.DIGITO,
//                                PRP.FAVORECIDO,
//                                PRP.CONTA_CORRENTE,
//                                PRP.DIG_CONTA,
//                                PRP.PARTICIPACAO,
//                                PRP.TIPO_CONTA,
//                                PRP.DESCR_TIPO_CONTA,
//                                PRP.FORMA_PAGTO,
//                                SUM(PRP.VALOR_SOCIO) AS VALOR_SOCIO
//                        FROM PROC_REC_PROP_SOCIOS(:EMPRESA,:REIMPRESSAO,:DATA_INICIO,:DATA_FIM,:COD_PROP,:PAGINA) PRP
//
//                        GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14";
//        $sth4 =$db->prepare($sqlSocios);
//        $sth4->bindParam(':EMPRESA', $row->EMPRESA, PDO::PARAM_INT);
//        $sth4->bindParam(':REIMPRESSAO', $reimpressao, PDO::PARAM_INT);
//        $sth4->bindParam(':DATA_INICIO', $data_i, PDO::PARAM_STR, 10);
//        $sth4->bindParam(':DATA_FIM', $data_f, PDO::PARAM_STR, 10);    
//        $sth4->bindParam(':COD_PROP', $row->COD_PROP, PDO::PARAM_INT);
//        $sth4->bindParam(':PAGINA', $row->X, PDO::PARAM_INT);
//        try{
//         $sth4->execute();
//        }
//        catch (PDOException $e) {
//         echo json_encode( array( 
//                 "error" => "erro na execução do sql: ".$e->getMessage()
//         ) );
//         exit(0); 
//        }
        
        
        
        
        
//        while ($rowSocios = $sth4->fetch(PDO::FETCH_OBJ)){
//                $htmlSocios=$htmlSocios.'<table border="0" width="100%" align="center">
//                    <tbody>
//                        <tr>
//                            <td WIDTH="80%" align="LEFT"> SOCIO: '.$rowSocios->COD_CLI.'-'.$rowSocios->NOME_CLI.' </td>                        
//                            <td WIDTH="20%" align="right"> '.number_format($rowSocios->VALOR_SOCIO, 2, ',', '.').' </td>                        
//                        </tr>
//                    </tbody>
//                </table>
//                <table border="0" width="100%" align="center">
//                    <tbody>
//                        <tr>
//                            <td WIDTH="50%" align="LEFT"> <b> '.$rowSocios->DESCR_F_PAGTO.' </b>  </td>                        
//                            <td WIDTH="50%" align="LEFT"> BANCO: '.$rowSocios->BANCO.' AGÊNCIA: '.$rowSocios->AGENCIA.' DIGITO: '.$rowSocios->DIGITO.' </td>
//                        </tr>
//                    </tbody>
//                </table>
//                <table border="0" width="100%" align="center">
//                    <tbody>
//                        <tr>
//                            <td WIDTH="50%" align="LEFT"> NOMINAL: '.$rowSocios->FAVORECIDO.'  </td>                        
//                            <td WIDTH="50%" align="LEFT"> C/C.: '.$rowSocios->CONTA_CORRENTE.'  DIGITO: '.$rowSocios->DIG_CONTA.' </td>
//                        </tr>
//                    </tbody>
//                </table>
//                <table border="0" width="100%" align="center">
//                    <tbody>
//                        <tr>
//                            <td WIDTH="20%" align="LEFT"> TIPO: '.$rowSocios->TIPO_CONTA.'-'.$rowSocios->DESCR_TIPO_CONTA.'  </td>                        
//                            <td WIDTH="80%" align="LEFT"> </td>
//                        </tr>
//                    </tbody>
//                </table>';
//        }   
        
        



    
    
    //$mpdf->WriteHTML('errou -'.$row->IMOVEL);
    $sql_qtd_voluntarios ="  SELECT count(v.nome) as qtd_voluntarios
                             FROM voluntarios v
                             WHERE (v.ESCALADO=:ESCALADO)
                             ORDER BY v.NOME";

    $sth2 =$db->prepare($sql_qtd_voluntarios);
    $sth2->bindParam(':ESCALADO', $escalado, PDO::PARAM_STR);
    
//    $sth2->bindParam(':IMOVEL', $row->IMOVEL, PDO::PARAM_INT);
//    $sth2->bindParam(':SEQUENCIA', $row->SEQUENCIA, PDO::PARAM_STR, 5);
//    $sth2->bindParam(':PARCELA', $row->PARCELA, PDO::PARAM_STR, 10);    
    
    try{
        $sth2->execute();
    }
    catch (PDOException $e) {
        echo json_encode( array( 
                "error" => "erro na execução do sql: ".$e->getMessage()
        ) );
        exit(0); 
    }
    
    $rowTotais = $sth2->fetch(PDO::FETCH_OBJ);    
    

    

$sth =$db->prepare($sql);
$sth->bindParam(':ESCALADO', $escalado, PDO::PARAM_STR);


try{
    $sth->execute();    
}
catch (PDOException $e) {
    echo json_encode( array( 
            "error" => "erro na execução do sql: ".$e->getMessage()
    ) );
    exit(0); 
}

$row = $sth->fetch(PDO::FETCH_OBJ);



//if ($row = $sth->fetch(PDO::FETCH_OBJ)) {    
    $html=' <table border="0" width="100%" align="center" class="pontilhado">
                <tbody>    
                    <tr>
                        <td width="70%" align=left style="font-size: 12pt;"> <b>TPE - Relação de Voluntários (Não Escalados)</b> </td>
                        <td width="50%" align=right  > '. date('d/m/Y')   .' </td>
                    </tr>
                </tbody>
            </table>
            '.$html_tracado.'
            
            <table border="0" width="100%" align="center" class="pontilhado">
                <tbody>
                    <tr>
                        <td WIDTH="30%" bgcolor="#CCCCCC"> Nome </td>
                        <td WIDTH="30%" align=left bgcolor="#CCCCCC"> Email </td>
                        <td WIDTH="20%" align=left bgcolor="#CCCCCC"> Telefone 1 </td>
                        <td WIDTH="20%" align=left bgcolor="#CCCCCC"> Telefone 2 </td>
                    </tr>
                </tbody>
            </table>

            '.$html_qtd_voluntarios.'
            
            <table border="0" width="100%" align="center">
            </table>   
            <table border="0" width="100%" align="right" class="pontilhado">
                <tbody>
                    <tr>
                        <td whidth="40%">  </td>
                        <td WIDTH="45%" align="right"> <b>TOTAL DE VOLUNTÁRIOS ( '.number_format($rowTotais->qtd_voluntarios, 0, ',', '.').' )</b> </td>                        
                    </tr>
                </tbody>                 
            </table> ';
    //echo $html;
    $mpdf=new mPDF('utf-8', 'A4-L');
    
    //$mpdf->setHeader('TPE - Relação de Voluntários (Não Escalados)');
    $mpdf->WriteHTML($html);
    $mpdf->setFooter('{PAGENO}');
    //$mpdf->AddPage();
//}    
$mpdf->Output();
//echo $html;
exit;





?>